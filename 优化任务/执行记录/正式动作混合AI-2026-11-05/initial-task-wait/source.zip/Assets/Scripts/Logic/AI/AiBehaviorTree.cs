using System;
using System.Collections.Generic;
using System.Linq;
using ProjectHero.Logic.Actions;
using ProjectHero.Logic.Commands;
using ProjectHero.Logic.Determinism;
using ProjectHero.Logic.Ids;
using ProjectHero.Logic.Snapshots;

namespace ProjectHero.Logic.AI
{
    public enum AiExecutionKind { SingleCommand = 0, UtilityBehaviorTree = 1 }
    public enum AiBehaviorStatus { Failure = 0, Running = 1, Success = 2 }

    // Stable node cursors: 0 = select/submit, 1 = acknowledge ingress, 2 = await terminal.
    // Each channel owns its cursor; responding never cancels an ordinary combat plan.
    public sealed record AiBehaviorTask(int Cursor = 0, long RequestTick = -1, long ProducerOrdinal = 0,
        long PlanId = 0, AiBehaviorStatus Status = AiBehaviorStatus.Failure, string Reason = "IDLE");
    public sealed record AiBehaviorMemory(AiBehaviorTask Ordinary, AiBehaviorTask Reaction)
    {
        public static AiBehaviorMemory Empty => new AiBehaviorMemory(new AiBehaviorTask(), new AiBehaviorTask());
        public void Encode(CanonicalEncoder encoder)
        {
            encoder.WriteString(AiBehaviorTree.Version);
            Write(Ordinary); Write(Reaction);
            void Write(AiBehaviorTask task)
            {
                encoder.WriteInt32(task.Cursor); encoder.WriteInt64(task.RequestTick);
                encoder.WriteInt64(task.ProducerOrdinal); encoder.WriteInt64(task.PlanId);
                encoder.WriteInt32((int)task.Status); encoder.WriteString(task.Reason);
            }
        }
    }

    /// <summary>Memoryful Sequence and reactive Selector. All persistent memory belongs to the canonical task record.</summary>
    public static class AiBehaviorNodes
    {
        public delegate AiBehaviorStatus Leaf(ref AiBehaviorTask memory);
        public static AiBehaviorStatus Sequence(ref AiBehaviorTask memory, params Leaf[] children)
        {
            while (memory.Cursor < children.Length)
            {
                var status = children[memory.Cursor](ref memory);
                memory = memory with { Status = status };
                if (status == AiBehaviorStatus.Running) return status;
                if (status == AiBehaviorStatus.Failure) { memory = memory with { Cursor = 0 }; return status; }
                memory = memory with { Cursor = memory.Cursor + 1 };
            }
            memory = memory with { Cursor = 0, Status = AiBehaviorStatus.Success };
            return AiBehaviorStatus.Success;
        }
        public static AiBehaviorStatus Selector(params Func<AiBehaviorStatus>[] children)
        {
            foreach (var child in children)
            {
                var status = child();
                if (status != AiBehaviorStatus.Failure) return status;
            }
            return AiBehaviorStatus.Failure;
        }
    }

    /// <summary>First hybrid: utility selects data-driven action tasks; the tree owns their asynchronous lifecycle.</summary>
    public static class AiBehaviorTree
    {
        public const string Version = "utility-behavior-tree-v1";
        public static AiDecision Tick(AiDecisionContext context, ulong seed, AiPolicyKind policy,
            AiBehaviorMemory memory, IAiExecutionFeedback feedback, long nextProducerOrdinal)
        {
            if (feedback == null) throw new LogicDefinitionException("AI_EXECUTION_FEEDBACK_MISSING");
            // Freeze V2 scoring/arbitration for this structural comparison. No extra gameplay rewards.
            var proposed = AiTacticalPolicy.Decide(context, seed, policy);
            var ordinary = memory.Ordinary; var reaction = memory.Reaction;
            var selectedEvaluation = proposed.Evaluations.FirstOrDefault(e => e.Chosen);
            CommandRequest selected = null;
            string reason = proposed.NoSelectionReason;
            bool reactionChosen = selectedEvaluation?.IsReaction == true;
            bool reactionWait = proposed.Evaluations.Any(e => e.IsReaction && e.RejectionCode == null) && !reactionChosen;
            // Consume both channels' receipts before priority arbitration: an urgent response must
            // not leave an ordinary acknowledgement unread until its per-Tick receipt has expired.
            BindReceipt(ref ordinary); BindReceipt(ref reaction);
            AiBehaviorNodes.Selector(Response, Ordinary, Wait);
            var evaluations = proposed.Evaluations.Select(e => e.Chosen && selected == null
                ? e with { Chosen = false, Reason = "TREE_WAITING_FOR_ACTUAL_RESULT" } : e).ToArray();
            return proposed with { Selected = selected, Evaluations = evaluations,
                NoSelectionReason = selected == null ? reason : null,
                Behavior = new AiBehaviorMemory(ordinary, reaction), Execution = AiExecutionKind.UtilityBehaviorTree,
                UnsupportedActionIds = Unsupported(context) };

            AiBehaviorStatus Response()
            {
                if (reaction.Cursor > 0 || reactionChosen)
                    return Run(ref reaction);
                if (!reactionWait) return AiBehaviorStatus.Failure;
                reason = "WAIT_REACTION_NOT_BENEFICIAL";
                return AiBehaviorStatus.Running;
            }
            AiBehaviorStatus Ordinary()
            {
                if (ordinary.Cursor == 0 && (proposed.Selected == null || reactionChosen)) return AiBehaviorStatus.Failure;
                return Run(ref ordinary);
            }
            AiBehaviorStatus Wait() => AiBehaviorStatus.Running;
            AiBehaviorStatus Run(ref AiBehaviorTask task)
                => AiBehaviorNodes.Sequence(ref task, Submit, Acknowledge, AwaitTerminal);
            void BindReceipt(ref AiBehaviorTask task)
            {
                if (task.Cursor != 1 || task.RequestTick > context.Snapshot.Tick) return;
                var status = Acknowledge(ref task);
                task = task with { Cursor = status == AiBehaviorStatus.Success ? 2 : 0,
                    Status = status == AiBehaviorStatus.Success ? AiBehaviorStatus.Running : status };
            }
            AiBehaviorStatus Submit(ref AiBehaviorTask task)
            {
                if (proposed.Selected == null) return AiBehaviorStatus.Failure;
                selected = proposed.Selected;
                task = new AiBehaviorTask(RequestTick: context.NextTick, ProducerOrdinal: nextProducerOrdinal,
                    Status: AiBehaviorStatus.Running, Reason: "REQUEST_QUEUED");
                return AiBehaviorStatus.Success;
            }
            AiBehaviorStatus Acknowledge(ref AiBehaviorTask task)
            {
                reason = "WAIT_COMMAND_RESULT";
                if (context.Snapshot.Tick < task.RequestTick) return AiBehaviorStatus.Running;
                var result = feedback.ReadSubmission(context.ControllerId, task.RequestTick, task.ProducerOrdinal);
                if (result == null || result.RejectionCode != null || result.PlanIds.Count != 1)
                {
                    reason = result?.RejectionCode ?? "AI_REQUEST_RESULT_MISSING";
                    task = task with { Reason = reason };
                    return AiBehaviorStatus.Failure;
                }
                task = task with { PlanId = result.PlanIds[0], Reason = "COMMAND_ACCEPTED" };
                return AiBehaviorStatus.Success;
            }
            AiBehaviorStatus AwaitTerminal(ref AiBehaviorTask task)
            {
                var plan = feedback.ReadPlan(context.ControllerId, task.PlanId);
                reason = plan == null ? "AI_PLAN_RESULT_MISSING" :
                    plan.State == (int)ActionPlanState.Completed ? "PLAN_COMPLETED" :
                    plan.State == (int)ActionPlanState.Terminated ? "PLAN_TERMINATED_" + plan.TerminationReason : "WAIT_PLAN_TERMINAL";
                task = task with { Reason = reason };
                return plan == null || plan.State == (int)ActionPlanState.Terminated ? AiBehaviorStatus.Failure
                    : plan.State == (int)ActionPlanState.Completed ? AiBehaviorStatus.Success : AiBehaviorStatus.Running;
            }
        }

        public static IReadOnlyList<string> Unsupported(AiDecisionContext context)
            => context.ControlledUnits.SelectMany(context.Snapshot.ActionSetOf).Distinct()
                .Where(id => context.Snapshot.FindAction(id)?.Type is not
                    (ActionType.Attack or ActionType.Move or ActionType.Guard or ActionType.Block or ActionType.Dodge))
                .Select(id => id.Value).OrderBy(id => id, StringComparer.Ordinal).ToArray();
    }
}
