using System;
using System.Collections.Generic;
using System.Linq;
using ProjectHero.Logic.AI;
using ProjectHero.Logic.Actions;
using ProjectHero.Logic.Commands;
using ProjectHero.Logic.Combat;
using ProjectHero.Logic.Events;
using ProjectHero.Logic.Ids;
using ProjectHero.Logic.Simulation;

namespace ProjectHero.Logic.Simulation
{
    public sealed partial class BattleSimulation
    {
        // Stage 18 is a decision boundary, before _tick/_currentSnapshot are committed in stage 19.
        // Reuse the HUD sanitizer with this explicit boundary; never hand AI a live simulation.
        internal IAiForecast CreateAiForecast(Snapshots.DecisionSnapshot decision)
        {
            if (decision == null || string.IsNullOrEmpty(decision.ControllerId.Value) || decision.Tick != _eventTick)
                throw new InvalidOperationException("AI_FORECAST_BOUNDARY_MISMATCH");
            var visible = new HashSet<long>(decision.VisiblePlans.Concat(decision.OwnPlans).Select(p => p.ActionPlanId));
            var template = CopyHudWorld(visible, decision.Tick);
            return new Snapshots.AiForecastWorld(decision, template, () => template.CopyHudWorld(visible));
        }
    }
}

namespace ProjectHero.Logic.Snapshots
{
    internal sealed class AiForecastWorld : IAiForecast
    {
        internal const int LookaheadTicks = 120;
        private readonly DecisionSnapshot _decision;
        private readonly BattleSimulation _template;
        private readonly Func<BattleSimulation> _fork;
        public AiForecastWorld(DecisionSnapshot decision, BattleSimulation template, Func<BattleSimulation> fork)
        { _decision = decision; _template = template; _fork = fork; }
        public void Dispose() => _template.Dispose();

        public AiActionForecast Evaluate(CommandRequest request)
        {
            using var world = _fork();
            long horizon = _decision.Tick + LookaheadTicks;
            string error = null;
            long start = 0, impact = 0, end = 0;
            var own = new HashSet<long>(_decision.ControlledUnitIds.Select(u => u.Value));
            var hostile = new HashSet<long>(_decision.VisibleUnits.Where(u => own.Any(id =>
                _decision.Classify(new UnitId(id), new UnitId(u.UnitId)) == Factions.UnitRelation.Hostile)).Select(u => u.UnitId));
            if (request != null)
            {
                error = request.ValidateStaticStructure();
                if (error == null && request.TargetTick != _decision.Tick + 1) error = "AI_FORECAST_TARGET_TICK";
                if (error == null && request.Scope is ScheduleEditScope scope && request.Payload is ScheduleEditPayload edits)
                {
                    var applied = world.ScheduleEditor.Apply(edits.Operations, request.TargetTick, scope.ExpectedScheduleRevision,
                        world.ScheduleRevision, expectedWindowId: scope.ExpectedWindowId, issuer: _decision.ControllerId);
                    error = applied.RejectionCode;
                    if (applied.Succeeded)
                    {
                        world.CloseHudScheduleTransaction(applied, request.TargetTick);
                        var plan = world.ScheduleAuthority.Registry.ActivePlans.OrderByDescending(p => p.ActionPlanId.Value).FirstOrDefault();
                        if (plan != null) { start = plan.StartTick; impact = plan.ImpactTick; end = plan.EndTick; }
                    }
                }
                else if (error == null && request.Scope is ReactionCommandScope reaction && request.Payload is ReactionCommandPayload payload)
                {
                    var opportunity = world.ReactionOpportunities.FindOpportunity(reaction.ReactionOpportunityId);
                    if (opportunity == null || !own.Contains(opportunity.DefenderUnitId.Value)) error = "AI_FORECAST_NOT_OWN_OPPORTUNITY";
                    else error = world.ReactionOpportunities.TryAcceptById(opportunity.Id, payload.ReactionActionSpecId,
                        request.TargetTick, payload.DodgeDestination, out _, payload.StartTick);
                }
                else if (error == null) error = CommandCodes.SCOPE_PAYLOAD_MISMATCH;
            }
            if (error != null) return new AiActionForecast(error, horizon, Array.Empty<UnitSnapshot>(), -1, 0, 0);
            var threats = _decision.VisiblePlans.Where(p => hostile.Contains(p.OwnerUnitId)
                && _decision.FindAction(new ActionSpecId(p.ActionSpecId))?.Type == ActionType.Attack)
                .ToDictionary(p => p.ActionPlanId, p => p.ImpactTick);
            var interrupted = new HashSet<long>(); var clashes = new HashSet<long>();
            long firstHit = -1;
            while (!world.IsEnded && world.Tick < horizon)
            {
                var before = world.CurrentSnapshot.Units.Where(u => hostile.Contains(u.UnitId)).Sum(u => (long)u.HealthQ10);
                long tick = world.Tick + 1;
                var result = world.Step(tick, world.CommandIngress.FreezeTick(tick));
                long after = result.Snapshot.Units.Where(u => hostile.Contains(u.UnitId)).Sum(u => (long)u.HealthQ10);
                if (firstHit < 0 && after < before) firstHit = tick;
                foreach (var fact in result.Events.Events)
                {
                    if (fact is ActionPlanTerminatedEvent terminated && threats.TryGetValue(terminated.ActionPlanId, out long due)
                        && terminated.Tick < due) interrupted.Add(terminated.ActionPlanId);
                    if (fact is ClashParticipantResolvedEvent clash && hostile.Contains(clash.OwnerUnitId.Value))
                        clashes.Add(clash.ActionPlanId.Value);
                }
            }
            return new AiActionForecast(null, horizon, world.CurrentSnapshot.Units, firstHit, interrupted.Count, clashes.Count, start, impact, end);
        }
    }
}
