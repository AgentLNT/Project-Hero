# 阶段三：可解释规则 AI（2026-11-03）

范围：[实施方案第 7 节](../../方案/战斗数值与AI实施验证方案-v0.1-2026-10-28.md)、[任务 14](../../14-可解释规则AI.md)。本轮交付三种可选策略、缺失的候选能力及确定性证据；生产仍默认旧确定性策略，正式数值未切换。

## 实现

`ControllerBinding.AiPolicy` 显式选择 `Legacy / SustainedOffense / SeekInterrupt / CautiousDefense`。非旧策略的种类及 `tactical-public-kernel-v1` 进入定义哈希；旧策略跳过新增编码，旧哈希锚点和 ReplayFormat 7 延续。注册同时拒绝未知策略及给 Player 绑定非旧 AI 策略。

候选构建与评分分别位于 `AiTacticalCandidateBuilder` 和 `AiTacticalPolicy`：

- 攻击按可见目标瞄准；在原排程预览解析前摇后，可为最近两个公开敌方命中时刻生成延迟对齐候选。
- Guard 作为普通动作生成。Move 主动生成规范 12 向、1/2 步距共 24 个目的地，不再只重排已有 Move；路径、边界、占位和时长由原排程/路径求解器判断。
- Block/Dodge 使用公布机会与落点，逐候选走真实资源、时序和轨道检查。反应每 Tick 检查并优先于普通动作；合法反应的最高收益不高于等待时，本 Tick 等待。无合法反应后才进入普通层，不与普通动作混合竞价。
- 普通动作每 6 Tick 思考一次；已有未完成轨道承诺时等待，避免不断追加预测计划。所有入选请求仍经注册入口于下一 Tick 提交，无主动关窗命令。

预览复用 HUD 的隔离世界复制接缝，删除对手未公开草稿及路径，在阶段 18 显式冻结当前决策边界，再运行同一 `BattleSimulation.Step`。AI 只能取得只读结果，不取得模拟写入面；预测不改变真实世界、序号或 RNG。实际生命变化、公开攻击在命中前的终止、拼刀与终点位置来自原内核，AI 不另算伤害、动量、控制或移动时间。

## 评分及限制

预测固定为当前 Tick 后 120 Tick，假设没有后续新命令，仍执行窗口切换、资源重置及已公开动作。它是条件预测，不代表未知对手后续决策。策略没有额外可变记忆；决策计数、下次思考 Tick 及派生 RNG 仍由原运行态快照记录。候选以包含动作、目标、朝向、目的地、机会及对齐时刻的完整稳定键排序，同分保留稳定键较小者。

以等待预览为基准，`D` 为额外敌方生命损失，`I` 为额外友方生命损失，单位均为 Q10；`P` 为最终最近敌方距离的改善，`C` 为新增提前取消数，`K` 为新增拼刀数：

| 策略 | 收益分 |
|---|---|
| 持续进攻 | `8D - 2I + 256P + 1024C + 256K` |
| 寻找打断 | `2D - 3I + 128P + 65536C + 24576K` |
| 谨慎防守 | `D - 12I + 64P + 2048C` |

统一扣除承诺剩余时长×8、反应资源点数×32，以及确有额外伤害时的首次伤害等待 Tick。v0.5 资源原始整数先按 `24576 = 1 点` 换算，避免与 Q10 生命混用。等待分数为 0；没有正收益候选时允许等待。权重是首版策略偏好，不是平衡指标。移动目前仅覆盖 24 个局部目的地，尚无多步战术搜索、对手建模或正式性能验收。

## 代表结果

同一公开重击在 Tick 100 命中，三种策略在 Tick 60 的首选为：

| 策略 | 实际首选 | 核心理由 |
|---|---|---|
| 持续进攻 | 快攻，61 开始、91 命中 | 预览增加 4096 Q10 敌方生命损失 |
| 寻找打断 | 钝击探针，70 开始、100 拼刀 | 原内核确认发生拼刀，降低预期来伤 |
| 谨慎防守 | Guard，61～121 | 原内核确认降低 3072 Q10 来伤 |

另有低稳定度探针验证提前控制取消：寻找打断选择钝击探针，真实敌方攻击在 Tick 100 前终止。远距场景选择主动 Move；仅 Guard 场景真实生成 Guard 计划；足额资源场景经真实受击获得资源后选择 Block；不足时记下 `ADRENALINE_INSUFFICIENT` 并等待。Dodge 的公布落点参与合法性及收益比较，本组足额场景最终选择 Block。

## 原生验证

| 验证 | 结果与证据 |
|---|---|
| 最终全量 EditMode | **1080/1080**，含新增 12 项；[full-editmode.xml](full-editmode.xml) |
| 生产 / Shadow 定向 PlayMode | **14/14**；[production-shadow-playmode.xml](production-shadow-playmode.xml) |
| 机制矩阵 | **62/62** 场，**9920 Tick**；生成时从磁盘输入重建并逐 Tick 重放通过 |
| 独立进程磁盘审计 | **62/62**，定义重建、AI 再生成、逐 Tick 事件/快照比较通过；[审计回执](native-disk-replay-audit.txt) |

矩阵为 8 种局面×3 种新策略×双向出生位置，加 8 场旧基线；公开威胁局面再对新策略及双向站位补种子 97，其他场使用种子 31。8 种局面为：空闲攻击、公开威胁、远距接近、仅 Guard、足额反应、缺额反应、较晚命中对齐、低稳定度提前打断。每场 160 Tick。

三种新策略合计 **54 场、0 个命令拒绝**。旧基线 8 场保留原行为，合计有 452 次拒绝，主要是反复提出资源不足的反应；未为改善对照而修改旧选择。`selected*` 统计已选择请求，不等于成功执行次数，须结合拒绝和事件阅读。实验对手是固定玩家脚本，不是完整对抗 AI，不能从这些数据推导胜率、强弱或后摇平衡。

主源码指纹：`b1778d52726676cba028a2dbfa18aa720c02f47fe9b790bb048b12b8fdf517ac`。范围为 `Assets/Scripts` 及 `Assets/Tests` 的全部 C#，路径排序后逐文件 SHA-256 再聚合；与 [source-fingerprint.txt](source-fingerprint.txt)、每场输入和独立审计一致。

## 证据入口与复跑

- [summary.csv](summary.csv)：每场选择数、拒绝数、最终生命及首选；[cases/](cases/) 保存输入、回放、事件、逐 Tick 选择及全部评分/淘汰理由。
- `*.input.json` 包含场景版本、策略版本、输入参数、定义哈希与源码指纹。原生审计从它重建定义，并读取同名 `.heroReplay`；仅注入已记录玩家事实，由 `ProductionBattleComposition` 从 Tick 0 重建 AI。
- `*.choices.csv` 包含每 Tick 的选择/等待原因；`*.decisions.csv` 包含资格拒绝、伤害差、来伤差、位置、提前取消、拼刀、资源、时间及最终入选理由。
- `pre-validation-baseline.zip/json` 保存开工时已有历史证据及已修改的场景/字体资产字节。测试生成的历史路径文件另行留档后恢复原字节，旧 6572 场扫描、原始哈希和回放不重写。早期调试 XML 只代表当次迭代，最终结论以收尾 XML、源码指纹和磁盘审计为准。

收尾恢复核对：482 个基线文件字节全部匹配，测试重新生成的 23 个文件另存 `validation-regenerated-files.zip`，详见 [historical-restoration.json](historical-restoration.json)。

```powershell
unity run . --editor-version 6000.6.2f1 --timeout 1800 --no-tail --format json -- -executeMethod ProjectHero.Editor.AiPolicyExperimentTools.Run
unity run . --editor-version 6000.6.2f1 --timeout 1800 --no-tail --format json -- -executeMethod ProjectHero.Editor.AiPolicyExperimentTools.AuditSaved
unity test . --editor-version 6000.6.2f1 --mode EditMode --output '优化任务/执行记录/规则AI阶段三-2026-11-03/full-editmode.xml' --timeout 900 --format json
```

## 下一阶段

固定本策略版本后，进入阶段四：对后摇 **31/40** 和相邻 **30/32/39/41** 做同策略对照，覆盖先手交换、双向站位、窗口阶段、单挑/2 对 2、开阔地/墙边；保留 **42/43/44、58/59/60** 及未参加筛选的场景作反例。阶段三机制矩阵不替代这些实验和人工试玩，正式参数仍待定。
