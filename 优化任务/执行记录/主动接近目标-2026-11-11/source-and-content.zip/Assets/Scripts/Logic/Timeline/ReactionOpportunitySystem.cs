using System;
using System.Collections.Generic;
using ProjectHero.Logic.Actions;
using ProjectHero.Logic.Combat;
using ProjectHero.Logic.Damage;
using ProjectHero.Logic.Definitions;
using ProjectHero.Logic.Events;
using ProjectHero.Logic.Factions;
using ProjectHero.Logic.Grid;
using ProjectHero.Logic.Ids;
using ProjectHero.Logic.Snapshots;
using ProjectHero.Logic.Determinism;
using ProjectHero.Logic.Replay;
using System.Globalization;
using System.Text;

namespace ProjectHero.Logic.Timeline
{
    /// <summary>反应机会系统新增的稳定码（不改名、不复用既有码）。</summary>
    public static class ReactionOpportunityCodes
    {
        public const string ATTACK_NOT_REACTABLE = "REACTION_ATTACK_NOT_REACTABLE";
        public const string LEAD_TOO_SHORT = "REACTION_LEAD_TOO_SHORT";
        public const string NO_REACHABLE_OPTION = "REACTION_NO_REACHABLE_OPTION";
        public const string SOURCE_NOT_ATTACK = "REACTION_SOURCE_NOT_ATTACK";
        public const string SOURCE_NOT_TELEGRAPHED = "REACTION_SOURCE_NOT_TELEGRAPHED";
        public const string SOURCE_ALREADY_OPEN = "REACTION_SOURCE_ALREADY_OPEN";
        public const string OPTION_ALREADY_RESOLVED = "REACTION_OPTION_ALREADY_RESOLVED";
        public const string OPPORTUNITY_NOT_OPEN = ReactionCodes.OPPORTUNITY_NOT_OPEN;

        /// <summary>
        /// 07-A：肾上腺素预留已经成功，但计划创建/注册未能提交 = <strong>内部矛盾</strong>
        /// （前置校验与工厂判定分叉）。它以稳定不变量错误令 Step 失败，
        /// 绝不静默留下"已扣费但没有计划"的半提交状态。
        /// </summary>
        public const string REACTION_ADRENALINE_COMMIT_INCONSISTENT =
            "REACTION_ADRENALINE_COMMIT_INCONSISTENT";
    }

    /// <summary>
    /// 区域攻击在 <c>TelegraphTick</c> 的<strong>逻辑威胁候选</strong>来源。
    /// 真实几何属于任务 06；任务 05 只定义接入面，默认实现明确"没有候选"（fail-closed），
    /// 绝不猜测区域、也绝不用"敌方单位"之类的表现标志代替几何。
    /// </summary>
    public interface IAreaThreatCandidateSource
    {
        /// <summary>返回候选单位（顺序无关；系统会按 <c>UnitId</c> 升序规范化）。</summary>
        IReadOnlyList<UnitId> CandidatesFor(ActionPlan sourcePlan, long telegraphTick);
    }

    /// <summary>任务 06 接入前的默认候选来源：<strong>不猜测</strong>，返回空。</summary>
    public sealed class NoAreaThreatCandidateSource : IAreaThreatCandidateSource
    {
        public static readonly NoAreaThreatCandidateSource Instance = new NoAreaThreatCandidateSource();

        public IReadOnlyList<UnitId> CandidatesFor(ActionPlan sourcePlan, long telegraphTick)
            => Array.Empty<UnitId>();
    }

    /// <summary>
    /// 接受反应前的<strong>资源/目的格事务接缝</strong>（任务 07/06 接入）。
    /// 默认实现只校验、不冻结；任务 07 在此处把肾上腺素/Cycle 预留从 Available 转入 Reserved。
    /// </summary>
    public interface IReactionPreparationPort
    {
        /// <summary>返回 null = 允许；否则返回稳定拒绝码，且不得留下任何已冻结副作用。</summary>
        string Prepare(ActionPlan sourcePlan, ReactionOption option, UnitId defenderUnitId, long tick);

        /// <summary>回滚 <see cref="Prepare"/> 可能产生的副作用（仅在后续步骤失败时调用）。</summary>
        void Rollback(ActionPlan sourcePlan, ReactionOption option, UnitId defenderUnitId, long tick);
    }

    /// <summary>
    /// <c>SourceThreatCancelled</c> 的"释放未消费预留"通知接收方（任务 07）。
    /// 未注入接收方时请求会<strong>排队保留</strong>（而不是静默丢弃），任务 07 可在装配后取走。
    /// </summary>
    public interface IReactionReservationReleaseSink
    {
        void ReleaseFor(ActionPlanId reactionPlanId, ReactionOpportunityId opportunityId, long tick);
    }

    /// <summary>
    /// 反应<strong>接受事务</strong>内的 <strong>Dodge 目的格预留</strong>接缝（任务 06 接入；
    /// 实现见 <c>ProjectHero.Logic.Movement.DodgeRelocationAuthority</c>）。
    ///
    /// 冻结语义：
    /// <list type="bullet">
    /// <item>它在反应计划被创建<strong>之前</strong>被调用，因此返回非 null 时整个接受事务必须
    /// 整条回滚（<see cref="IReactionPreparationPort.Rollback"/> + <see cref="ReleaseDestination"/>），
    /// 且<strong>不</strong>留下任何已冻结副作用；</item>
    /// <item>成功时按 <c>ReactionOpportunityId</c> 为 <c>SourceImpactTick</c> 冻结合法目的格；
    /// 计划创建成功后由 <see cref="BindPlan"/> 绑定 <c>ActionPlanId</c>；</item>
    /// <item>冲突胜者<strong>只</strong>由 <paramref name="commandSequence"/>（任务 03 网关的规范命令序）
    /// 决定，后到者稳定拒绝、不可抢占。</item>
    /// </list>
    /// </summary>
    public interface IDodgeDestinationReservationPort
    {
        /// <summary>返回 null = 目的格已为该机会合法冻结；否则稳定拒绝码且零写入。</summary>
        string ReserveDestination(
            ReactionOpportunityId opportunityId,
            UnitId defenderUnitId,
            ActionSpecId dodgeSpecId,
            GridPoint destination,
            long triggerTick,
            long commandSequence,
            long tick, long? endTick = null);

        /// <summary>计划创建成功后绑定 <c>ActionPlanId</c>（不改变预留的合法性）。</summary>
        void BindPlan(ReactionOpportunityId opportunityId, ActionPlanId reactionPlanId);

        /// <summary>释放该机会的预留（幂等；用于接受事务回滚与来源威胁取消）。</summary>
        void ReleaseDestination(ReactionOpportunityId opportunityId);
    }

    /// <summary>
    /// 一条待发送的预留释放通知。
    /// </summary>
    public sealed record ReactionReservationReleaseRequest(
        ActionPlanId ReactionPlanId, ReactionOpportunityId OpportunityId, long Tick);

    /// <summary>运行时反应选项：在冻结的 <see cref="ReactionOption"/> 之上叠加发布/过期状态。</summary>
    public sealed class ReactionOptionRuntime
    {
        internal ReactionOptionRuntime(ReactionOption option, bool isPublished)
        {
            Option = option;
            IsPublished = isPublished;
        }

        public ReactionOption Option { get; }

        public ActionSpecId ReactionActionSpecId => Option.ReactionActionSpecId;

        public ActionType ReactionType => Option.ReactionType;

        public long ResponseDeadlineTick => Option.ResponseDeadlineTick;

        /// <summary>是否满足 <c>ResponseDeadlineTick &gt;= TelegraphTick + CommandIngressLeadTicks</c>。</summary>
        public bool IsPublished { get; }

        /// <summary>仍然开放（可被接受、也仍会产生过期事件）。</summary>
        public bool IsOpen { get; internal set; } = true;

        /// <summary>结果码（Accepted / Expired / SourceCancelled）；null = 尚未有结果。</summary>
        public string OutcomeCode { get; internal set; }
    }

    /// <summary>
    /// 运行时反应机会。它是<strong>权威活动对象</strong>：状态机固定为
    /// <c>Open/Accepted/Triggered/Expired/SourceCancelled/BattleEnded</c>，
    /// 只有 <c>Open</c> 接收命令。
    /// </summary>
    public sealed class ReactionOpportunityRuntime
    {
        internal ReactionOpportunityRuntime(
            ReactionOpportunityId id, ActionPlanId sourceAttackPlanId, UnitId defenderUnitId,
            long telegraphTick, long triggerTick, List<ReactionOptionRuntime> options)
        {
            Id = id;
            SourceAttackPlanId = sourceAttackPlanId;
            DefenderUnitId = defenderUnitId;
            TelegraphTick = telegraphTick;
            SourceImpactTick = triggerTick;
            Options = options;
        }

        public ReactionOpportunityId Id { get; }

        public ActionPlanId SourceAttackPlanId { get; }

        public UnitId DefenderUnitId { get; }

        /// <summary>首版 = 来源攻击的 <c>StartTick</c>。</summary>
        public long TelegraphTick { get; }

        /// <summary>= 来源攻击的 <c>ImpactTick</c>（由 Logic 固定推导，命令无法声明）。</summary>
        public long SourceImpactTick { get; }

        public IReadOnlyList<ReactionOptionRuntime> Options { get; }

        public ReactionOpportunityState State { get; internal set; } = ReactionOpportunityState.Open;

        public string CloseReason { get; internal set; }

        public long ClosedAtTick { get; internal set; } = -1L;

        public ActionPlanId BoundActionPlanId { get; internal set; }

        public string AcceptedActionSpecId { get; internal set; }

        public bool IsOpen => State == ReactionOpportunityState.Open;

        /// <summary>仍然开放的选项数。</summary>
        public int OpenOptionCount
        {
            get
            {
                int count = 0;
                for (int i = 0; i < Options.Count; i++)
                {
                    if (Options[i].IsOpen) count++;
                }
                return count;
            }
        }
    }

    public sealed partial class ReactionOpportunitySystem
    {
        private readonly ActionScheduleAuthority _authority;
        private readonly LogicIdGenerator _idGenerator;
        private readonly ActionPlanFactory _factory;
        private readonly BattleDefinition _definition;
        private readonly IFactionRelationResolver _factions;
        private readonly IAreaThreatCandidateSource _areaCandidates;
        private readonly ActionPlanTerminalCoordinator _coordinator;
        private readonly ReactionPlanner _planner;

        private readonly List<ReactionOpportunityRuntime> _active = new List<ReactionOpportunityRuntime>();
        private readonly Dictionary<long, ReactionOpportunitySnapshot> _frozen =
            new Dictionary<long, ReactionOpportunitySnapshot>();
        private readonly List<LogicEvent> _emitted = new List<LogicEvent>();
        private readonly List<ReactionReservationReleaseRequest> _pendingReleases =
            new List<ReactionReservationReleaseRequest>();

        public ReactionOpportunitySystem(
            ActionScheduleAuthority authority,
            ActionPlanFactory factory,
            BattleDefinition definition,
            IFactionRelationResolver factions,
            LogicIdGenerator idGenerator,
            IAreaThreatCandidateSource areaCandidates = null,
            ActionPlanTerminalCoordinator coordinator = null)
        {
            _authority = authority ?? throw new ArgumentNullException(nameof(authority));
            _factory = factory ?? throw new ArgumentNullException(nameof(factory));
            _definition = definition ?? throw new ArgumentNullException(nameof(definition));
            _factions = factions ?? throw new ArgumentNullException(nameof(factions));
            // 任务 05 收尾 R1（缺陷 D2）：机会 ID 的唯一分配器是任务 03 冻结契约的
            // LogicIdGenerator.NextReactionOpportunityId()。它<strong>必填</strong>——
            // 缺省回落会重新引入"第二份计数状态"这一缺陷形态。
            _idGenerator = idGenerator ?? throw new ArgumentNullException(nameof(idGenerator));
            _areaCandidates = areaCandidates ?? NoAreaThreatCandidateSource.Instance;
            _coordinator = coordinator;
            _planner = new ReactionPlanner(_authority, _factory, _definition);
        }

        /// <summary>把选项变成真实 Locked 计划的唯一入口。</summary>
        public ReactionPlanner Planner => _planner;

        /// <summary>事件发射端口（装配方接到 <c>LogicEventOutbox.Emit</c>）。未注入时事件只进内部缓冲。</summary>
        public Action<Func<long, LogicEvent>> EventSink { get; set; }

        /// <summary>预留释放通知接收方（任务 07）。</summary>
        public IReactionReservationReleaseSink ReservationReleaseSink { get; set; }

        /// <summary>资源/目的格事务接缝（任务 07/06）。默认只校验。</summary>
        public IReactionPreparationPort PreparationPort { get; set; }

        /// <summary>
        /// 任务 06 的 <strong>Dodge 目的格预留端口</strong>（未装配时为 null ⇒ 只校验不冻结，
        /// 与任务 05 的原有语义一致）。装配后，Dodge 的接受事务会在创建计划之前先冻结合法目的格；
        /// 预留失败即整条接受事务回滚。
        /// </summary>
        public IDodgeDestinationReservationPort DestinationReservationPort { get; set; }

        /// <summary>
        /// <strong>07-E：肾上腺素事务端口</strong>（<c>IAdrenalineLedgerPort</c>；唯一权威是
        /// <c>AdrenalineLedger</c> / <c>AdrenalineLedgerRegistry</c>，本系统<strong>不</strong>持有第二份状态）。
        ///
        /// 装配后：
        /// <list type="bullet">
        /// <item><strong>接受</strong>（<see cref="TryAccept"/> 全族）在创建/注册计划之前按权威
        /// <c>ActionSpec.AdrenalineCost</c> 预留，失败即整条接受失败且零副作用（07-A）；</item>
        /// <item><strong>触发确认</strong>（<see cref="ConfirmTrigger"/>）在同一提交边界消费预留（07-B）；</item>
        /// <item><strong>来源威胁取消</strong>（<see cref="CancelForSourceThreat"/>）按周期规则释放预留，
        /// 并确定性地下发 <see cref="PendingReservationReleases"/> 里的排队项（07-C）；其余终态一律不退款（07-D）。</item>
        /// </list>
        ///
        /// 未设置时（任务 05/06 的既有装配）本系统<strong>保持既有语义</strong>：不抛异常、
        /// 不改变任何既有拒绝码、不改变排队行为。属性与 <see cref="Planner"/> 上的同名属性是
        /// <strong>同一个状态</strong>（转发），因此不存在两个可写端口。
        /// </summary>
        public Resources.IAdrenalineLedgerPort AdrenalinePort
        {
            get => _planner.AdrenalinePort;
            set => _planner.AdrenalinePort = value;
        }

        /// <summary>活动机会（按 <c>ReactionOpportunityId</c> 升序的稳定枚举）。</summary>
        public IReadOnlyList<ReactionOpportunityRuntime> ActiveOpportunities => _active;

        /// <summary>
        /// 按 <c>ReactionOpportunityId</c> 查找机会（<strong>只读</strong>；未找到返回 <c>null</c>）。
        /// 它只暴露权威活动对象的只读视图；命令路径仍然是 <see cref="TryAccept"/>。
        /// </summary>
        public ReactionOpportunityRuntime FindOpportunity(ReactionOpportunityId opportunityId)
            => FindById(opportunityId);

        /// <summary>Explicit diagnostic lookup; frozen bindings never enter per-Tick projection.</summary>
        public ReactionOpportunitySnapshot FindFrozenOpportunity(ReactionOpportunityId id)
            => _frozen.TryGetValue(id.Value, out var value) ? value : null;

        public bool TryGetDefenderUnitId(ReactionOpportunityId id, out UnitId defender)
        {
            var active = FindById(id);
            if (active != null) { defender = active.DefenderUnitId; return defender.IsValid; }
            var frozen = FindFrozenOpportunity(id);
            defender = frozen == null ? default : new UnitId(frozen.DefenderUnitId);
            return defender.IsValid;
        }

        /// <summary>
        /// Stage 19: seal only after both source and bound plan are terminal and no release
        /// notification remains pending. Accepted/Triggered bindings must survive until then.
        /// Full immutable payloads preserve options and closure/trigger provenance.
        /// </summary>
        public IReadOnlyList<HistoryArchiveCandidate> CollectFrozenBindingCandidates(long tick)
        {
            if (_active.Count == 0) return Array.Empty<HistoryArchiveCandidate>();
            List<HistoryArchiveCandidate> records = null;
            for (int i = _active.Count - 1; i >= 0; i--)
            {
                var opportunity = _active[i];
                if (opportunity.IsOpen) continue;
                var source = _authority.Registry.Find(opportunity.SourceAttackPlanId);
                if (source == null || !source.IsTerminal) continue;
                if (opportunity.BoundActionPlanId.IsValid)
                {
                    var bound = _authority.Registry.Find(opportunity.BoundActionPlanId);
                    if (bound == null || !bound.IsTerminal) continue;
                }
                bool pending = false;
                for (int p = 0; p < _pendingReleases.Count; p++)
                    if (_pendingReleases[p].OpportunityId == opportunity.Id) { pending = true; break; }
                if (pending) continue;
                var snapshot = BuildSnapshot(opportunity);
                var encoder = new CanonicalEncoder();
                encoder.BeginDomain("ReactionOpportunityBinding.v4");
                encoder.WriteBytes(Encoding.UTF8.GetBytes(ReplayEventComparison.CanonicalValue(snapshot)));
                if (records == null) records = new List<HistoryArchiveCandidate>();
                records.Add(new HistoryArchiveCandidate(tick, HistoryRecordKind.ReactionOpportunityBinding,
                    opportunity.Id.Value.ToString(CultureInfo.InvariantCulture), encoder.ToArray(), HistorySealProof.Sealed));
                _frozen.Add(opportunity.Id.Value, snapshot);
                _active.RemoveAt(i);
            }
            if (records == null) return Array.Empty<HistoryArchiveCandidate>();
            records.Sort((a, b) => a.CompareCanonical(b));
            return records;
        }

        /// <summary>尚未被接收方取走的预留释放请求（顺序 = 产生顺序）。</summary>
        public IReadOnlyList<ReactionReservationReleaseRequest> PendingReservationReleases => _pendingReleases;

        /// <summary>本 Tick 已发射的事件（按产生顺序；<c>Sequence</c> 为 0 占位）。</summary>
        public IReadOnlyList<LogicEvent> EmittedEvents => _emitted;

        /// <summary>The committed outbox/replay owns history; this diagnostic buffer holds one Tick.</summary>
        public void BeginTick() => _emitted.Clear();

        /// <summary>取走并清空事件缓冲（注入 <see cref="EventSink"/> 后仍可用作审计）。</summary>
        public List<LogicEvent> DrainEmittedEvents()
        {
            var copy = new List<LogicEvent>(_emitted);
            _emitted.Clear();
            return copy;
        }

        // ————————————————————————————————————————————————————————————
        // 公开机会
        // ————————————————————————————————————————————————————————————

        /// <summary>
        /// 为一条已锁定/启动的攻击公开机会。
        /// 返回 null = 已处理（<paramref name="opened"/> 里追加了新建的机会）；
        /// 否则返回稳定拒绝码，且<strong>不写任何状态</strong>。
        /// </summary>
        public string TryOpenForTelegraph(ActionPlan sourcePlan, long tick, List<ReactionOpportunityRuntime> opened)
        {
            if (sourcePlan == null || !sourcePlan.IsOrdinary) return ReactionOpportunityCodes.SOURCE_NOT_ATTACK;
            if (sourcePlan.ActionType != ActionType.Attack) return ReactionOpportunityCodes.SOURCE_NOT_ATTACK;
            if (sourcePlan.IsEditable) return ReactionOpportunityCodes.SOURCE_NOT_TELEGRAPHED;

            ActionSpec spec = _definition.FindAction(sourcePlan.ActionSpecId);
            if (spec == null) return ActionPlanCodes.ACTION_PLAN_SPEC_NOT_FOUND;
            var attack = spec.Payload as AttackPayloadSpec;
            if (attack == null) return ReactionOpportunityCodes.SOURCE_NOT_ATTACK;

            // 首版 TelegraphTick = StartTick。
            long telegraphTick = sourcePlan.StartTick;
            if (tick < telegraphTick) return ReactionOpportunityCodes.SOURCE_NOT_TELEGRAPHED;

            if ((attack.Tags & AttackTagMask.Reactable) == 0)
                return ReactionOpportunityCodes.ATTACK_NOT_REACTABLE;

            long lead = sourcePlan.ImpactTick - telegraphTick;
            if (lead < _definition.ReactionRules.MinimumReactionLeadTicks)
                return ReactionOpportunityCodes.LEAD_TOO_SHORT;

            if (FindBySource(sourcePlan.ActionPlanId) != null)
                return ReactionOpportunityCodes.SOURCE_ALREADY_OPEN;

            List<UnitId> candidates = CollectDefenders(sourcePlan, attack, telegraphTick);
            if (candidates.Count == 0) return ReactionOpportunityCodes.NO_REACHABLE_OPTION;

            long ingressLead = _definition.ReactionRules.CommandIngressLeadTicks;
            bool anyCreated = false;

            for (int c = 0; c < candidates.Count; c++)
            {
                UnitId defender = candidates[c];
                List<ReactionOptionRuntime> options = BuildOptions(sourcePlan, attack, defender, telegraphTick, ingressLead);
                if (options.Count == 0) continue;

                var runtime = new ReactionOpportunityRuntime(
                    // 唯一分配器：任务 03 契约的 LogicIdGenerator（缺陷 D2 修复后的单一来源）。
                    _idGenerator.NextReactionOpportunityId(),
                    sourcePlan.ActionPlanId, defender, telegraphTick, sourcePlan.ImpactTick, options);

                _active.Add(runtime);
                SortActive();
                anyCreated = true;
                if (opened != null) opened.Add(runtime);

                var published = new List<string>();
                for (int o = 0; o < options.Count; o++)
                {
                    if (options[o].IsPublished) published.Add(options[o].ReactionActionSpecId.Value);
                }

                Record(new ReactionOpportunityOpenedEvent(
                    tick, 0L, runtime.Id.Value, runtime.SourceAttackPlanId.Value, defender.Value,
                    telegraphTick, runtime.SourceImpactTick, published));
            }

            return anyCreated ? null : ReactionOpportunityCodes.NO_REACHABLE_OPTION;
        }

        // ————————————————————————————————————————————————————————————
        // 接受命令
        // ————————————————————————————————————————————————————————————

        /// <summary>
        /// 处理一条反应命令（Block/Dodge）。<strong>载荷不提供 Tick</strong>：
        /// <c>SourceImpactTick</c> 恒等于来源攻击的 <c>ImpactTick</c>。
        /// 返回 null = 已接受（<paramref name="plan"/> 是新建的、直接 Locked 的统一计划）。
        /// </summary>
        public string TryAccept(
            ReactionOpportunityId opportunityId,
            UnitId defenderUnitId,
            ActionSpecId optionSpecId,
            long tick,
            out ActionPlan plan)
            => TryAccept(opportunityId, defenderUnitId, optionSpecId, tick, null, out plan);

        /// <summary>
        /// 命令路径的便捷入口：<strong>防御者由机会自身决定</strong>，命令不携带单位
        /// （"谁能替该单位提交"属于任务 07 的提交权限，不属于本系统）。
        /// 未找到机会 ⇒ <c>OPPORTUNITY_NOT_OPEN</c>，零写入。
        /// </summary>
        public string TryAcceptById(
            ReactionOpportunityId opportunityId, ActionSpecId optionSpecId, long tick,
            GridPoint? dodgeDestination, out ActionPlan plan, long? startTick = null)
            => TryAcceptByIdWithCommandSequence(opportunityId, optionSpecId, 0L, tick, dodgeDestination, out plan, startTick);

        public ReactionStartPreview PreviewStart(ReactionOpportunityId opportunityId, ActionSpecId optionSpecId,
            long commandTick, long? requestedStartTick = null)
        {
            var opportunity = FindById(opportunityId);
            if (opportunity == null || !opportunity.IsOpen)
                return new ReactionStartPreview(0,0,0,0,null,ReactionCodes.OPPORTUNITY_NOT_OPEN);
            ReactionOptionRuntime selected = null;
            foreach (var option in opportunity.Options)
                if (option.ReactionActionSpecId == optionSpecId) selected = option;
            string admission = selected == null ? ReactionCodes.OPPORTUNITY_OPTION_NOT_OFFERED
                : !selected.IsPublished ? ReactionCodes.OPTION_NOT_PUBLISHED
                : !selected.IsOpen ? ReactionOpportunityCodes.OPTION_ALREADY_RESOLVED
                : commandTick > selected.ResponseDeadlineTick ? ReactionCodes.OPTION_DEADLINE_ELAPSED : null;
            if (admission != null) return new ReactionStartPreview(0,0,opportunity.SourceImpactTick,0,null,admission);
            ActionSpec spec = _definition.FindAction(optionSpecId);
            string error = ReactionPlanner.TryResolveReactionInterval(spec, opportunity.SourceImpactTick,
                requestedStartTick, commandTick, out long start, out long duration);
            long end = error == null ? checked(start + duration) : start;
            long hardEnd = checked(opportunity.SourceImpactTick + 1);
            ActorLane lane = _authority.FindLane(opportunity.DefenderUnitId);
            long? yield = null;
            if (error == null && lane != null)
            {
                if (lane.IsSubmissionLocked) error = ReactionCodes.REACTION_LANE_SUBMISSION_LOCKED;
                if (lane.TryFindOverlapExcept(start, hardEnd - start, null,
                    p => DodgeMovementInvalidationSeam.DodgeMayInvalidate(p,spec.Type,start),out _))
                    error = ReactionCodes.REACTION_LANE_INTERVAL_OCCUPIED;
                foreach (ActionPlan p in lane.Plans)
                    if (p.IsOrdinary && p.StartTick >= hardEnd && p.StartTick < end
                        && (!yield.HasValue || p.StartTick < yield.Value)) yield = p.StartTick;
            }
            return new ReactionStartPreview(start,end,opportunity.SourceImpactTick,hardEnd,yield,error);
        }

        /// <summary>
        /// 命令路径的便捷入口（携带任务 03 网关的规范命令序）。
        /// 该序号是 Dodge 目的格预留冲突的<strong>唯一</strong>胜者依据。
        /// </summary>
        public string TryAcceptByIdWithCommandSequence(
            ReactionOpportunityId opportunityId, ActionSpecId optionSpecId, long commandSequence, long tick,
            GridPoint? dodgeDestination, out ActionPlan plan, long? startTick = null)
        {
            ReactionOpportunityRuntime opportunity = FindById(opportunityId);
            if (opportunity == null)
            {
                plan = null;
                return ReactionOpportunityCodes.OPPORTUNITY_NOT_OPEN;
            }
            return TryAcceptWithCommandSequence(
                opportunityId, opportunity.DefenderUnitId, optionSpecId, commandSequence, tick,
                dodgeDestination, out plan, startTick);
        }

        /// <summary>
        /// 与 <see cref="TryAccept(ReactionOpportunityId, UnitId, ActionSpecId, long, out ActionPlan)"/> 同语义，
        /// 但把命令携带的 <paramref name="dodgeDestination"/>（仅 Dodge 允许）落到计划的
        /// <c>Destination</c> 上：换位事务属于任务 06/08，目的格必须先被权威记录下来，
        /// 绝不能在命令 Tick 结束后丢失。
        /// </summary>
        public string TryAccept(
            ReactionOpportunityId opportunityId,
            UnitId defenderUnitId,
            ActionSpecId optionSpecId,
            long tick,
            GridPoint? dodgeDestination,
            out ActionPlan plan, long? startTick = null)
            => TryAcceptWithCommandSequence(
                opportunityId, defenderUnitId, optionSpecId, 0L, tick, dodgeDestination, out plan, startTick);

        /// <summary>
        /// 与 <see cref="TryAccept(ReactionOpportunityId, UnitId, ActionSpecId, long, GridPoint?, out ActionPlan)"/>
        /// 同语义，但显式携带任务 03 网关的规范命令序 <paramref name="commandSequence"/>：
        /// 它是 Dodge 目的格预留冲突的<strong>唯一</strong>胜者依据（后到者稳定拒绝、不可抢占）。
        /// </summary>
        public string TryAcceptWithCommandSequence(
            ReactionOpportunityId opportunityId,
            UnitId defenderUnitId,
            ActionSpecId optionSpecId,
            long commandSequence,
            long tick,
            GridPoint? dodgeDestination,
            out ActionPlan plan, long? startTick = null)
        {
            plan = null;

            ReactionOpportunityRuntime opportunity = FindById(opportunityId);
            if (opportunity == null) return ReactionOpportunityCodes.OPPORTUNITY_NOT_OPEN;
            if (opportunity.DefenderUnitId != defenderUnitId)
                return ReactionCodes.OPPORTUNITY_DEFENDER_MISMATCH;
            if (!opportunity.IsOpen) return ReactionOpportunityCodes.OPPORTUNITY_NOT_OPEN;

            ReactionOptionRuntime option = null;
            for (int i = 0; i < opportunity.Options.Count; i++)
            {
                if (opportunity.Options[i].ReactionActionSpecId != optionSpecId) continue;
                option = opportunity.Options[i];
                break;
            }
            if (option == null) return ReactionCodes.OPPORTUNITY_OPTION_NOT_OFFERED;
            if (!option.IsPublished) return ReactionCodes.OPTION_NOT_PUBLISHED;
            if (!option.IsOpen) return ReactionOpportunityCodes.OPTION_ALREADY_RESOLVED;
            // 到期判定在<strong>截止 Tick 的命令阶段之后</strong>：本 Tick 恰好等于截止 Tick 仍然可接受。
            if (tick > option.ResponseDeadlineTick) return ReactionCodes.OPTION_DEADLINE_ELAPSED;

            ActionPlan sourcePlan = _authority.Registry.Find(opportunity.SourceAttackPlanId);
            if (sourcePlan == null) return ReactionCodes.REACTION_SOURCE_THREAT_ALREADY_TERMINAL;
            if (sourcePlan.IsTerminal) return ReactionCodes.REACTION_SOURCE_THREAT_ALREADY_TERMINAL;

            ActionSpec optionSpec = _definition.FindAction(optionSpecId);
            if (optionSpec == null) return ActionPlanCodes.ACTION_PLAN_SPEC_NOT_FOUND;
            if (optionSpec.Type != ActionType.Block && optionSpec.Type != ActionType.Dodge)
                return ReactionCodes.REACTION_ACTION_NOT_BLOCK_OR_DODGE;

            // 目的格只属于 Dodge：Block 携带目的格必须在命令结构校验处就被拒绝，
            // 这里做第二道防线（绝不让 Block 悄悄换位）。
            if (optionSpec.Type == ActionType.Block && dodgeDestination.HasValue)
                return ReactionCodes.REACTION_ACTION_NOT_BLOCK_OR_DODGE;

            // 07-A：接受反应的**权威费用**只来自 ActionSpec.AdrenalineCost
            // （AdrenalineRules.ValidateReactionCost 所约束的同一字段）；命令载荷与调用参数
            // 都不携带、也不能覆盖它。这里只判定"该费用是否允许这次接受"，
            // 真正的预留由 ReactionPlanner 在同一事务内用同一权威字段完成（见下）。
            // 未装配肾上腺素端口时跳过（任务 05/06 的既有装配保持既有语义）。
            if (AdrenalinePort != null)
            {
                string costError = _definition.AdrenalineRules.ValidateReactionCost(
                    optionSpec.Type, optionSpec.AdrenalineCost);
                if (costError != null) return costError;
            }

            ActorLane lane = _authority.FindLane(defenderUnitId);
            if (lane != null && lane.IsSubmissionLocked)
                return ReactionCodes.REACTION_LANE_SUBMISSION_LOCKED;

            // 07-A：固定反应区间与 Lane 的占位判定提前到**任何冻结与预留之前**
            // （区间按 ActionPlan.ApplyReactionInterval 的同一规则从 ActionSpec 推导）。
            // 因此"区间被占用"这条拒绝路径既不占用 ActionPlanId、也不写 Lane、
            // 也不触碰肾上腺素账本，且选项保持开放。
            string intervalError = ReactionPlanner.TryResolveReactionInterval(
                optionSpec, opportunity.SourceImpactTick, startTick, tick, out long intervalStart, out long intervalLength);
            if (intervalError != null) return intervalError;

            // 任务 07 裁定 A（放宽接受侧，使 MovementOriginInvalidatedByDodge 在生产路径可达）：
            // Dodge 的固定反应区间**允许**覆盖"它自己在 SourceImpactTick 会失效掉的后续 Editable 移动族"。
            // 容忍判据收敛在 DodgeMovementInvalidationSeam.DodgeMayInvalidate（与失效闭包过滤器
            // 逐字一致），本预检与 ReactionPlanner 的复核共用它，避免两处判据分叉。
            // Block 不换位 ⇒ 绝不容忍任何重叠（保持原判据）。
            if (lane != null && lane.TryFindOverlapExcept(
                    intervalStart, opportunity.SourceImpactTick + 1L - intervalStart, null,
                    overlapping => DodgeMovementInvalidationSeam.DodgeMayInvalidate(
                        overlapping, optionSpec.Type, intervalStart),
                    out _))
                return ReactionCodes.REACTION_LANE_INTERVAL_OCCUPIED;

            // 冻结注入的准备接缝（任务 06 的空间/资源预检；失败必须整条回滚）。
            // 07-A：肾上腺素预留不在这里 —— 它必须在"候选 ActionPlanId 已解析、且不再有
            // 任何可预期校验"之后，与计划创建/注册合成同一个提交（见下）。
            string prepared = PreparationPort?.Prepare(sourcePlan, option.Option, defenderUnitId, tick);
            if (prepared != null) return prepared;

            // 任务 06：Dodge 目的格在**计划创建之前**冻结（按 ReactionOpportunityId 键）。
            // 目的格无效 ⇒ 接受事务整条回滚：命令被拒绝、机会保持 Open、单位不移动、零写入。
            if (dodgeDestination.HasValue && DestinationReservationPort != null)
            {
                string reserved = DestinationReservationPort.ReserveDestination(
                    opportunity.Id, defenderUnitId, optionSpecId, dodgeDestination.Value,
                    opportunity.SourceImpactTick, commandSequence, tick, checked(intervalStart + intervalLength));
                if (reserved != null)
                {
                    PreparationPort?.Rollback(sourcePlan, option.Option, defenderUnitId, tick);
                    return reserved;
                }
            }

            // 07-A：先解析候选 ActionPlanId（只读观察：**不**推进 ID 计数器），再由规划器在
            // "预留 → 创建并注册"的同一事务里提交。预留失败 ⇒ 整条接受失败且零副作用
            // （不注册计划、不写 Lane、不占用 ID、不消费机会）；候选值必须恰好等于工厂
            // 随后分配到的值（ReactionPlanner 以 ACTION_PLAN_ID_RESERVATION_MISMATCH 复核）。
            // 反应接受不得要求窗口、ExpectedWindowId 或 ConcurrentActionSystem 授权（00 号规则 26）。
            ActionPlanId candidatePlanId = new ActionPlanId(_idGenerator.NextActionPlanIdValue);
            string planError = _planner.TryPlanWithReservation(
                opportunity, option, sourcePlan, tick, dodgeDestination, candidatePlanId,
                out ActionPlan reaction, intervalStart);
            if (planError != null)
            {
                DestinationReservationPort?.ReleaseDestination(opportunity.Id);
                PreparationPort?.Rollback(sourcePlan, option.Option, defenderUnitId, tick);
                return planError;
            }

            // 计划已存在 ⇒ 把 ActionPlanId 绑定到已冻结的目的格预留上（不改预留的合法性）。
            if (dodgeDestination.HasValue && DestinationReservationPort != null)
                DestinationReservationPort.BindPlan(opportunity.Id, reaction.ActionPlanId);

            opportunity.State = ReactionOpportunityState.Accepted;
            opportunity.BoundActionPlanId = reaction.ActionPlanId;
            opportunity.AcceptedActionSpecId = optionSpecId.Value;
            option.IsOpen = false;
            option.OutcomeCode = ReactionOptionOutcomes.Accepted;
            CloseRemainingOptions(opportunity, option);

            plan = reaction;
            return null;
        }

        // ————————————————————————————————————————————————————————————
        // 过期与关闭
        // ————————————————————————————————————————————————————————————

        /// <summary>
        /// 处理截止：每个选项在其 <c>ResponseDeadlineTick</c> 的命令阶段<strong>结束之后</strong>
        /// （即 <c>tick &gt; deadline</c>）恰好过期一次；最后一个开放选项过期时关闭机会。
        /// </summary>
        public void ExpireDueOptions(long tick)
        {
            for (int i = 0; i < _active.Count; i++)
            {
                ReactionOpportunityRuntime opportunity = _active[i];
                if (!opportunity.IsOpen) continue;

                for (int o = 0; o < opportunity.Options.Count; o++)
                {
                    ReactionOptionRuntime option = opportunity.Options[o];
                    if (!option.IsOpen) continue;
                    if (tick <= option.ResponseDeadlineTick) continue;

                    option.IsOpen = false;
                    option.OutcomeCode = ReactionOptionOutcomes.Expired;

                    bool closes = opportunity.OpenOptionCount == 0;
                    Record(new ReactionOptionExpiredEvent(
                        tick, 0L, opportunity.Id.Value, opportunity.DefenderUnitId.Value,
                        option.ReactionActionSpecId.Value, option.ResponseDeadlineTick, closes));

                    if (closes) CloseOpportunity(opportunity, ReactionOpportunityState.Expired,
                        ReactionCloseReasons.AllOptionsExpired, tick, -1L);
                }
            }
        }

        /// <summary>
        /// 来源攻击在 <c>SourceImpactTick</c> 前终止：关闭机会、以
        /// <c>SourceThreatCancelled</c> 终止绑定反应，并<strong>发出释放未消费预留的通知</strong>。
        /// 返回被终止的反应计划 id（按稳定序）。
        /// </summary>
        public List<ActionPlanId> CancelForSourceThreat(ActionPlanId sourceAttackPlanId, long tick)
        {
            var terminated = new List<ActionPlanId>();
            for (int i = 0; i < _active.Count; i++)
            {
                ReactionOpportunityRuntime opportunity = _active[i];
                if (opportunity.SourceAttackPlanId != sourceAttackPlanId || tick > opportunity.SourceImpactTick) continue;
                if (!opportunity.IsOpen && opportunity.State != ReactionOpportunityState.Accepted) continue;

                for (int o = 0; o < opportunity.Options.Count; o++)
                {
                    ReactionOptionRuntime option = opportunity.Options[o];
                    if (option.OutcomeCode == ReactionOptionOutcomes.Accepted) continue;
                    option.IsOpen = false;
                    option.OutcomeCode = ReactionOptionOutcomes.SourceCancelled;
                }

                if (opportunity.BoundActionPlanId.IsValid)
                {
                    ActionPlan bound = _authority.Registry.Find(opportunity.BoundActionPlanId);
                    if (bound != null && !bound.IsTerminal)
                    {
                        if (_coordinator != null)
                        {
                            _coordinator.EnterTerminal(bound, ActionTerminationReason.SourceThreatCancelled, tick);
                        }
                        terminated.Add(bound.ActionPlanId);
                    }
                    RequestReservationRelease(bound == null ? opportunity.BoundActionPlanId : bound.ActionPlanId,
                        opportunity.Id, tick);
                }

                CloseOpportunity(opportunity, ReactionOpportunityState.SourceCancelled,
                    ReactionCloseReasons.SourceThreatCancelled, tick,
                    opportunity.BoundActionPlanId.IsValid ? opportunity.BoundActionPlanId.Value : -1L);
            }
            return terminated;
        }

        /// <summary>战斗结束 Finalizer：关闭全部仍未关闭的机会（同一个 Finalizer，不另写一套清理）。</summary>
        public void CloseAllForBattleEnd(long tick)
        {
            for (int i = 0; i < _active.Count; i++)
            {
                ReactionOpportunityRuntime opportunity = _active[i];
                if (!opportunity.IsOpen && opportunity.State != ReactionOpportunityState.Accepted) continue;
                for (int o = 0; o < opportunity.Options.Count; o++)
                {
                    ReactionOptionRuntime option = opportunity.Options[o];
                    if (option.IsOpen) { option.IsOpen = false; option.OutcomeCode = ReactionOptionOutcomes.Expired; }
                }
                CloseOpportunity(opportunity, ReactionOpportunityState.BattleEnded,
                    ReactionCloseReasons.BattleEnded, tick,
                    opportunity.BoundActionPlanId.IsValid ? opportunity.BoundActionPlanId.Value : -1L);
            }
        }

        /// <summary>
        /// 任务 06/08 的 SourceImpactTick 位置事务<strong>成功</strong>之后的确认接缝。
        /// 只有它能把 <c>Accepted</c> 推进到 <c>Triggered</c> 并发射
        /// <see cref="ReactionTriggeredEvent"/>；本任务绝不伪造触发。
        ///
        /// 07-B：同一提交边界内消费该反应的肾上腺素预留
        /// （<c>IAdrenalineLedgerPort.ConsumeAtTrigger</c>；幂等）。
        /// </summary>
        public string ConfirmTrigger(ReactionOpportunityId opportunityId, long tick)
        {
            ReactionOpportunityRuntime opportunity = FindById(opportunityId);
            if (opportunity == null)
                return FindFrozenOpportunity(opportunityId)?.State == (int)ReactionOpportunityState.Triggered
                    ? null : ReactionOpportunityCodes.OPPORTUNITY_NOT_OPEN;
            bool alreadyTriggered = opportunity.State == ReactionOpportunityState.Triggered;
            if (!alreadyTriggered && opportunity.State != ReactionOpportunityState.Accepted)
                return ReactionOpportunityCodes.OPPORTUNITY_NOT_OPEN;

            ActionPlan bound = _authority.Registry.Find(opportunity.BoundActionPlanId);
            if (bound == null) return ReactionCodes.REACTION_SOURCE_THREAT_ALREADY_TERMINAL;

            // 07-B：SourceImpactTick 的预留消费与"触发确认"是**同一个提交边界** —— 只有反应
            // 实际执行（任务 06/08 的位置/换位事务成功）之后才会走到这里，因此
            // 既不会"触发之前消费"，也不会留下"触发成功但仍持预留"的空洞。
            // 账本保证幂等（无预留 ⇒ 无操作，不重复消费）；重复确认路径同样调用它，
            // 因此"端口晚于首次确认才装配"这一装配顺序也不会留下永久预留。
            AdrenalinePort?.ConsumeAtTrigger(bound.ActionPlanId);

            if (alreadyTriggered) return null;   // 幂等：重复确认不重复发事件

            bound.ReactionTriggeredAtTick = tick;
            opportunity.State = ReactionOpportunityState.Triggered;
            Record(new ReactionTriggeredEvent(
                tick, 0L, opportunity.Id.Value, bound.ActionPlanId.Value,
                opportunity.SourceAttackPlanId.Value, opportunity.DefenderUnitId.Value,
                opportunity.SourceImpactTick, (int)bound.ActionType));
            return null;
        }

        // ————————————————————————————————————————————————————————————
        // 生命周期事件（由阶段 7/19 调用；同一发射路径）
        // ————————————————————————————————————————————————————————————

        public void EmitPlanCreated(ActionPlan plan, long tick)
        {
            if (plan == null) return;
            Record(new ActionPlanCreatedEvent(
                tick, 0L, plan.ActionPlanId.Value, (int)plan.Origin, plan.OwnerUnitId.Value,
                plan.ActionSpecId.Value, (int)plan.ActionType, plan.StartTick, plan.EndTick,
                plan.LastRequestedStartTick, plan.CreatedAtTick, _authority.ScheduleRevision));
        }

        public void EmitPlanLocked(ActionPlan plan, long tick)
        {
            if (plan == null) return;
            Record(new ActionPlanLockedEvent(
                tick, 0L, plan.ActionPlanId.Value, plan.OwnerUnitId.Value,
                plan.StartTick, plan.LockedAtTick, _authority.ScheduleRevision));
        }

        public void EmitPlanAutoDeferred(
            ActionPlan plan, string blockerReasonCode, long oldStartTick, long retryAtTick,
            IReadOnlyList<long> ripplePlanIds, long tick)
        {
            if (plan == null) return;
            Record(new ActionPlanAutoDeferredEvent(
                tick, 0L, plan.ActionPlanId.Value, plan.OwnerUnitId.Value, blockerReasonCode,
                oldStartTick, plan.StartTick, retryAtTick, plan.AutomaticDeferralCount,
                ripplePlanIds ?? Array.Empty<long>(), _authority.ScheduleRevision));
        }

        public void EmitPlanTerminated(ActionPlan plan, long tick)
        {
            if (plan == null) return;
            Record(new ActionPlanTerminatedEvent(
                tick, 0L, plan.ActionPlanId.Value, plan.OwnerUnitId.Value,
                (int)plan.TerminationReason,
                ActionTerminationReasons.CodeOf(plan.TerminationReason),
                plan.TerminalTick, _authority.ScheduleRevision));
        }

        public void EmitPlanCompleted(ActionPlan plan, long tick)
        {
            if (plan == null) return;
            Record(new ActionPlanCompletedEvent(
                tick, 0L, plan.ActionPlanId.Value, plan.OwnerUnitId.Value,
                plan.TerminalTick, _authority.ScheduleRevision));
        }

        // ————————————————————————————————————————————————————————————
        // 快照
        // ————————————————————————————————————————————————————————————

        /// <summary>活动机会的规范化快照（按 <c>ReactionOpportunityId</c> 升序）。</summary>
        public IReadOnlyList<ReactionOpportunitySnapshot> BuildSnapshots()
        {
            if (_active.Count == 0) return Array.Empty<ReactionOpportunitySnapshot>();
            var snapshots = new List<ReactionOpportunitySnapshot>(_active.Count);
            for (int i = 0; i < _active.Count; i++)
                snapshots.Add(BuildSnapshot(_active[i]));
            return snapshots;
        }

        private static ReactionOpportunitySnapshot BuildSnapshot(ReactionOpportunityRuntime opportunity)
        {
            var options = new ReactionOptionSnapshot[opportunity.Options.Count];
            for (int o = 0; o < options.Length; o++)
            {
                var option = opportunity.Options[o];
                options[o] = new ReactionOptionSnapshot(option.ReactionActionSpecId.Value, (int)option.ReactionType,
                    option.ResponseDeadlineTick, option.IsOpen, option.IsPublished, option.OutcomeCode);
            }
            return new ReactionOpportunitySnapshot(opportunity.Id.Value, opportunity.DefenderUnitId.Value,
                opportunity.SourceAttackPlanId.Value, opportunity.SourceImpactTick, opportunity.TelegraphTick,
                (int)opportunity.State, opportunity.CloseReason, opportunity.ClosedAtTick,
                opportunity.BoundActionPlanId.Value, opportunity.AcceptedActionSpecId, Array.AsReadOnly(options));
        }

        // ————————————————————————————————————————————————————————————
        // 内部
        // ————————————————————————————————————————————————————————————

        private List<UnitId> CollectDefenders(ActionPlan sourcePlan, AttackPayloadSpec attack, long telegraphTick)
        {
            var candidates = new List<UnitId>();
            var seen = new HashSet<long>();

            if (attack.TargetPolicy == TargetPolicy.PrimaryTargetOnly)
            {
                if (sourcePlan.PrimaryTargetUnitId.HasValue && sourcePlan.PrimaryTargetUnitId.Value.IsValid)
                    candidates.Add(sourcePlan.PrimaryTargetUnitId.Value);
            }
            else
            {
                IReadOnlyList<UnitId> area = _areaCandidates.CandidatesFor(sourcePlan, telegraphTick);
                if (area != null)
                {
                    for (int i = 0; i < area.Count; i++)
                    {
                        if (!area[i].IsValid) continue;
                        candidates.Add(area[i]);
                    }
                }
            }

            // 候选只经<strong>权威关系解析器 + Attack 的 AllowedTargetRelations</strong> 过滤：
            // 不读 IsPlayerControlled、Controller 类型或任何"默认敌方"标志。
            var accepted = new List<UnitId>();
            for (int i = 0; i < candidates.Count; i++)
            {
                UnitId candidate = candidates[i];
                if (!candidate.IsValid) continue;
                if (!seen.Add(candidate.Value)) continue;
                if (!_factory.TryGetOwnerFacts(candidate, out ActionPlanOwnerFacts facts)) continue;
                if (!facts.IsAlive) continue;
                if (candidate == sourcePlan.OwnerUnitId) continue;
                if (!_factions.Allows(attack.AllowedTargetRelations, sourcePlan.OwnerUnitId, candidate)) continue;
                accepted.Add(candidate);
            }

            accepted.Sort((a, b) => a.Value.CompareTo(b.Value));
            return accepted;
        }

        private List<ReactionOptionRuntime> BuildOptions(
            ActionPlan sourcePlan, AttackPayloadSpec attack, UnitId defender,
            long telegraphTick, long ingressLead)
        {
            var options = new List<ReactionOptionRuntime>();
            bool hasBlockable = HasBlockableContact(attack);
            bool hasDodgeable = (attack.Tags & AttackTagMask.Dodgeable) != 0;
            if (!hasBlockable && !hasDodgeable) return options;

            _factory.TryGetOwnerFacts(defender, out ActionPlanOwnerFacts defenderFacts);
            ActionSetDefinition actionSet = string.IsNullOrEmpty(defenderFacts.ActionSetId.Value)
                ? null
                : _definition.FindActionSet(defenderFacts.ActionSetId);

            // 按 ActionSpecId Ordinal 升序枚举全部候选反应动作。
            var reactions = new List<ActionSpec>();
            IReadOnlyList<ActionSpec> all = _definition.Actions;
            if (all != null)
            {
                for (int i = 0; i < all.Count; i++)
                {
                    ActionSpec spec = all[i];
                    if (spec == null) continue;
                    if (spec.Type != ActionType.Block && spec.Type != ActionType.Dodge) continue;
                    reactions.Add(spec);
                }
            }
            reactions.Sort((a, b) => string.CompareOrdinal(a.ActionSpecId.Value, b.ActionSpecId.Value));

            for (int i = 0; i < reactions.Count; i++)
            {
                ActionSpec spec = reactions[i];
                bool isBlock = spec.Type == ActionType.Block;
                if (isBlock && !hasBlockable) continue;
                if (!isBlock && !hasDodgeable) continue;

                // 动作集合归属：只在单位声明了 ActionSet 且该集合可解析时生效（与创建期同口径）。
                if (actionSet != null && !actionSet.Contains(spec.ActionSpecId)) continue;

                if ((spec.Timing is BlockReactionTimingSpec block && block.DurationTicks <= 0)
                    || (spec.Timing is DodgeReactionTimingSpec dodge && dodge.DurationTicks <= 0)) continue;
                long deadline = sourcePlan.ImpactTick - ingressLead;
                if (deadline <= 0L) continue;

                bool published = deadline >= telegraphTick + ingressLead;
                options.Add(new ReactionOptionRuntime(
                    new ReactionOption(spec.ActionSpecId, spec.Type, deadline), published));
            }

            // 只保留真正公开的选项；没有公开选项的候选不产生机会。
            var publishedOnly = new List<ReactionOptionRuntime>();
            for (int i = 0; i < options.Count; i++)
            {
                if (options[i].IsPublished) publishedOnly.Add(options[i]);
            }
            return publishedOnly;
        }


        /// <summary>来源至少有一个可格挡伤害分量<strong>或</strong>动量时才提供 Block。</summary>
        private static bool HasBlockableContact(AttackPayloadSpec attack)
        {
            if (attack.ForceMultiplier > 0f) return true;
            IReadOnlyList<DamageComponentSpec> components = attack.DamageComponents;
            if (components == null) return false;
            for (int i = 0; i < components.Count; i++)
            {
                if ((components[i].Tags & DamageTagMask.Blockable) != 0) return true;
            }
            return false;
        }

        private void CloseRemainingOptions(ReactionOpportunityRuntime opportunity, ReactionOptionRuntime accepted)
        {
            for (int i = 0; i < opportunity.Options.Count; i++)
            {
                ReactionOptionRuntime option = opportunity.Options[i];
                if (option == accepted) continue;
                if (!option.IsOpen) continue;
                // 已接受 ⇒ 机会不再接收命令；其余选项既不是"过期"也不是"被接受"，
                // 因此只关闭、不写结果码（绝不伪造过期事件）。
                option.IsOpen = false;
            }
        }

        private void CloseOpportunity(
            ReactionOpportunityRuntime opportunity, ReactionOpportunityState state,
            string reason, long tick, long boundPlanId)
        {
            if (opportunity.State != ReactionOpportunityState.Open &&
                opportunity.State != ReactionOpportunityState.Accepted) return;

            opportunity.State = state;
            opportunity.CloseReason = reason;
            opportunity.ClosedAtTick = tick;
            Record(new ReactionOpportunityClosedEvent(
                tick, 0L, opportunity.Id.Value, opportunity.SourceAttackPlanId.Value,
                opportunity.DefenderUnitId.Value, reason, tick, boundPlanId));
        }

        private void RequestReservationRelease(ActionPlanId reactionPlanId, ReactionOpportunityId opportunityId, long tick)
        {
            // 任务 05/06 冻结的通知语义（接收方优先，否则就地释放，再否则排队保留）：
            // 逐字保留，未装配肾上腺素端口时行为完全不变。
            NotifyReservationRelease(reactionPlanId, opportunityId, tick);

            // 07-C：肾上腺素释放与上面的"目的格预留通知"是两条独立、幂等的通道。
            // 它只认来源威胁取消（调用者只有 CancelForSourceThreat），未装端口时为无操作。
            TryDispatchAdrenalineRelease(reactionPlanId);
        }

        /// <summary>
        /// 任务 05/06 冻结的预留释放通知（<strong>逐字保留</strong>的原实现）：
        /// 有接收方 ⇒ 交给接收方；绑定计划已终态/不存在且目的格端口本身是接收方 ⇒ 就地释放；
        /// 其余情形（"绑定计划仍非终态且没有接收方"）<strong>排队保留</strong>，绝不静默丢弃。
        /// </summary>
        private void NotifyReservationRelease(
            ActionPlanId reactionPlanId, ReactionOpportunityId opportunityId, long tick)
        {
            if (ReservationReleaseSink != null)
            {
                ReservationReleaseSink.ReleaseFor(reactionPlanId, opportunityId, tick);
                return;
            }

            // 没有接收方时排队保留（绝不静默丢弃）：任务 07 装配后取走。
            //
            // 任务 06 小修轮 R4/B-2（独立验证 L-4）：调用点（CancelForSourceThreat）只在
            // "绑定计划仍非终态"时经统一终态协调器进入终态，而终态清理是 Dodge 目的格预留的
            // 常规释放路径。绑定计划**已经是终态**时协调器幂等跳过 ⇒ 若这里只排队，
            // 预留就只能等任务 07 消费队列（或永远不被释放）。
            //
            // 本方法改为**确定性释放**：只要"绑定计划不存在或已终态"（即本 Tick 不可能再由
            // 终态清理路径负责），就把释放就地下发给目的格预留端口（DodgeRelocationAuthority
            // 实现了 IReactionReservationReleaseSink ⇒ 幂等）。生产装配下该预留在计划进入终态时
            // 已被 MovementAndReservation = 500 参与者释放过，因此这句是**幂等的重复释放**；
            // 它的价值在于自定义装配（未把 Dodge 预留挂到终态参与者上）也**不可能**泄漏，
            // 而不是修补一条当前可达的生产缺陷。
            //
            // 仍会进入队列的只剩一种情形：绑定计划**仍非终态**且没有接收方。
            // 那是任务 05 冻结的语义（请求排队保留给任务 07），不是遗漏。
            if (reactionPlanId.IsValid &&
                !(_authority.Registry.Find(reactionPlanId) is ActionPlan bound && !bound.IsTerminal))
            {
                if (DestinationReservationPort is IReactionReservationReleaseSink portSink)
                {
                    portSink.ReleaseFor(reactionPlanId, opportunityId, tick);
                    return;
                }
            }

            _pendingReleases.Add(new ReactionReservationReleaseRequest(reactionPlanId, opportunityId, tick));
        }

        /// <summary>
        /// <strong>07-C：把排队中的"来源威胁取消 ⇒ 释放未消费预留"请求确定性地下发到肾上腺素端口，
        /// 并在下发后清空对应队列项。</strong>
        ///
        /// 它是本 Tick 处理边界的消费者（绑定计划进入终态后、或 Tick 末由装配方调用一次）：
        /// <list type="bullet">
        /// <item><strong>稳定顺序</strong>：按 <c>(ActionPlanId, ReactionOpportunityId)</c> 升序下发，
        /// 与入队顺序无关；同一计划只下发一次；</item>
        /// <item><strong>幂等</strong>：重复调用不会重复下发（队列项已清空；账本对已释放的预留也是无操作）；</item>
        /// <item><strong>不退款集合</strong>（07-D）：绑定计划已因<strong>其他</strong>原因进入终态
        /// （主动取消/被控制/死亡/目的格失效/已触发等）的条目<strong>不</strong>下发、也<strong>不</strong>清除
        /// （保留可审计事实，绝不调用任何释放/返还）；</item>
        /// <item>未装配肾上腺素端口时（任务 05/06 的既有装配）返回 0 且<strong>不</strong>改动队列 ——
        /// 既有"排队保留给任务 07"的语义完全不变。</item>
        /// </list>
        /// 返回实际下发的<strong>不同计划</strong>数。
        /// </summary>
        public int DispatchPendingReservationReleases()
        {
            if (AdrenalinePort == null || _pendingReleases.Count == 0) return 0;

            var ordered = new List<ReactionReservationReleaseRequest>(_pendingReleases);
            ordered.Sort(CompareReleaseRequests);

            var dispatchedPlanIds = new List<long>();
            for (int i = 0; i < ordered.Count; i++)
            {
                ReactionReservationReleaseRequest request = ordered[i];
                if (!IsAdrenalineReleaseAdmissible(request.ReactionPlanId)) continue;
                if (dispatchedPlanIds.Contains(request.ReactionPlanId.Value)) continue;

                AdrenalinePort.ReleaseForSourceThreatCancelled(request.ReactionPlanId);
                dispatchedPlanIds.Add(request.ReactionPlanId.Value);
            }

            if (dispatchedPlanIds.Count == 0) return 0;

            // 下发后清空对应队列项（按已下发的计划键，而不是重新判定状态）。
            for (int i = _pendingReleases.Count - 1; i >= 0; i--)
            {
                if (dispatchedPlanIds.Contains(_pendingReleases[i].ReactionPlanId.Value))
                    _pendingReleases.RemoveAt(i);
            }
            return dispatchedPlanIds.Count;
        }

        /// <summary>
        /// 07-C 的单条下发（来源取消路径内的即时下发；未装端口时为无操作）。
        /// </summary>
        private bool TryDispatchAdrenalineRelease(ActionPlanId reactionPlanId)
        {
            if (AdrenalinePort == null) return false;
            if (!IsAdrenalineReleaseAdmissible(reactionPlanId)) return false;

            AdrenalinePort.ReleaseForSourceThreatCancelled(reactionPlanId);
            return true;
        }

        /// <summary>
        /// <strong>07-D：肾上腺素释放的准入判定</strong> —— 只有"来源威胁取消且反应尚未触发"才可释放。
        ///
        /// 调用者只有来源取消路径（<see cref="CancelForSourceThreat"/>，且只处理
        /// <c>Open/Accepted</c> 的机会 ⇒ 反应<strong>尚未触发</strong>）；这里再排除
        /// "绑定计划已因<strong>其他</strong>原因进入终态"：防御者主动取消、被控制、死亡、
        /// 目的格失效、<c>InterruptedByControl</c> 等终态一律<strong>不</strong>退款
        /// （00 号规则 27 / 任务 07「必须产出」7 第四段）。
        ///
        /// 未注册的计划返回 true：账本里不可能存在该计划的预留（预留与注册在同一事务内），
        /// 因此端口调用是幂等无操作。
        /// </summary>
        private bool IsAdrenalineReleaseAdmissible(ActionPlanId reactionPlanId)
        {
            if (!reactionPlanId.IsValid) return false;

            ActionPlan bound = _authority.Registry.Find(reactionPlanId);
            if (bound == null) return true;
            if (!bound.IsTerminal) return true;   // 机会已按 SourceCancelled 关闭 ⇒ 永不触发
            return bound.TerminationReason == ActionTerminationReason.SourceThreatCancelled;
        }

        /// <summary>释放请求的规范顺序：<c>ActionPlanId</c> 升序 → <c>ReactionOpportunityId</c> 升序。</summary>
        private static int CompareReleaseRequests(
            ReactionReservationReleaseRequest left, ReactionReservationReleaseRequest right)
        {
            int byPlan = left.ReactionPlanId.Value.CompareTo(right.ReactionPlanId.Value);
            if (byPlan != 0) return byPlan;
            return left.OpportunityId.Value.CompareTo(right.OpportunityId.Value);
        }

        private ReactionOpportunityRuntime FindById(ReactionOpportunityId id)
        {
            for (int i = 0; i < _active.Count; i++)
            {
                if (_active[i].Id == id) return _active[i];
            }
            return null;
        }

        private ReactionOpportunityRuntime FindBySource(ActionPlanId sourcePlanId)
        {
            for (int i = 0; i < _active.Count; i++)
            {
                if (_active[i].SourceAttackPlanId == sourcePlanId) return _active[i];
            }
            return null;
        }

        private void SortActive()
            => _active.Sort((a, b) => a.Id.Value.CompareTo(b.Id.Value));

        private void Record(LogicEvent logicEvent)
        {
            if (logicEvent == null) return;
            _emitted.Add(logicEvent);
            if (EventSink == null) return;
            LogicEvent captured = logicEvent;
            EventSink(sequence => captured with { Sequence = sequence });
        }
    }
}
